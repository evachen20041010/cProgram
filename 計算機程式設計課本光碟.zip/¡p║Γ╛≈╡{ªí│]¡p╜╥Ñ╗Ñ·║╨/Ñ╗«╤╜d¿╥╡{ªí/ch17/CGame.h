class CGame {
public:
	char m_cIcon;
	CGame();
	void Update();
};