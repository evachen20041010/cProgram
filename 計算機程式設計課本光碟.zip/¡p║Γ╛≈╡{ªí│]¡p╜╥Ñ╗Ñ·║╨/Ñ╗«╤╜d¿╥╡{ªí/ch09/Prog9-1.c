#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	system("pause"); return(0);
 }