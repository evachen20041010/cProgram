#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	char ch = '\0'; int ix = 0; 
	printf("��J�@�Ӿ��:"); scanf("%d",&ix);
//	printf("��J�@�Ӧr��:"); scanf("%c",&ch);
	printf("ch = %d, ix = %d\n",ch,ix);
	system("pause");
	return(0);
}
