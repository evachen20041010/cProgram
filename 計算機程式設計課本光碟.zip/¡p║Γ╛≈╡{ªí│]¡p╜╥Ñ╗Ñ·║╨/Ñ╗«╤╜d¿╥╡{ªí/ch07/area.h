#define PI 3.1415926
#define CIRCLE(r) ((PI)*(r)*(r))
#define RECTANGLE(length,height) ((length)*(height))
#define TRIANGLE(base,height) ((base)*(height)/2.)